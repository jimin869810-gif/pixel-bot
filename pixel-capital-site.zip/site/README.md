# Pixel Capital · 개인용 자동매매 사이트 (Bybit + TradingAgents)

서버 한 대에서 **분석(TradingAgents) → 매매(Bybit) → 웹 화면(픽셀 사무실)** 이 한 프로세스로 돌아가요.
나 혼자 쓰는 용도이고, 로그인(비밀번호)이 있어야 열려요.

```
폰 브라우저 ──(Tailscale/HTTPS)──> server.py ──> engine.py ──> TradingAgents (LLM 분석)
                                      │                  └──> Bybit (ccxt)
                                      └ static/index.html (사무실 화면)
```

## 모드 (처음엔 반드시 이 순서로)
| 순서 | MODE | 의미 |
|---|---|---|
| 1 | `paper` | 주문 없음. Bybit 시세로 가상 매매. **최소 1~2주** |
| 2 | `testnet` | Bybit 테스트넷(가짜 돈)으로 실제 주문 흐름 검증. **며칠** |
| 3 | `live` | 실계좌. `CONFIRM_LIVE=I_UNDERSTAND_THE_RISK` 필요. 시작 시 오토 OFF |

## 설치 (Ubuntu 24.04 기준)
```bash
sudo apt update && sudo apt install -y git python3-venv
mkdir -p ~/site && cd ~/site          # 이 폴더 내용을 여기에 올리세요
python3 -m venv venv && source venv/bin/activate
git clone https://github.com/TauricResearch/TradingAgents.git
pip install ./TradingAgents && pip install -r requirements.txt
cp .env.example .env && chmod 600 .env && nano .env   # DASH_PASSWORD, LLM 키 등
set -a; source .env; set +a
python server.py                      # 먼저 눈으로 확인
```

## 폰에서 접속하기 (공개 인터넷에 직접 열지 마세요)
가장 안전하고 쉬운 방법은 **Tailscale** 이에요. 서버와 폰에 Tailscale 을 깔고 같은 계정으로 로그인하면, 서버가 인터넷에 노출되지 않은 채 폰에서만 접속돼요.
```bash
curl -fsSL https://tailscale.com/install.sh | sh && sudo tailscale up
sudo tailscale serve --bg 8080        # HTTPS 로 사무실 열기 (명령은 버전별로 다를 수 있어요. 공식 문서 확인)
```
도메인과 HTTPS 프록시(Caddy 등)로 여는 방법도 있지만, 그 경우 비밀번호를 아주 길게 하세요.

## 24시간 상시 실행
`deploy/pixelbot.service` 를 `/etc/systemd/system/` 에 복사(사용자명/경로 수정) 후
```bash
sudo systemctl enable --now pixelbot
journalctl -u pixelbot -f
```

## Bybit 키 발급
- **현물(Spot) 주문·조회 권한만**. 출금 권한은 절대 금지.
- 서버 IP 를 API 키의 화이트리스트에 등록.
- 테스트넷 키(testnet.bybit.com)와 실계좌 키(bybit.com)는 따로 발급돼요.
- 서버 지역에 따라 Bybit 접속이 막힐 수 있어요(예: 미국 IP). 싱가포르·도쿄 등을 권장해요.
- 거주 국가에서 Bybit 이용이 허용되는지는 본인이 확인하세요.

## 화면 사용법
- **사무실**: 코인 선택, 차트, 캐릭터 탭 → 해당 분석가 리포트, ACE 최종 판정
- **트레이딩**: 총자산, 포지션(개별 청산), 최근 판정, 청산 내역
- **제어**: 지금 분석, 전체 청산 + 오토 OFF, 한도 확인. 하단 버튼으로 오토 ON/OFF

## 안전장치
- 1회 주문 상한(`MAX_ORDER_USDT`), 일일 손실 한도, 손절/익절 감시(20초 주기)
- 실거래는 오토 OFF 로 시작, 로그인 필수, 비밀번호 없으면 서버가 시작하지 않아요
- 상태 변경 요청은 커스텀 헤더 필요(다른 사이트에서의 몰래 요청 방지)
- 시스템 정지: `sudo systemctl stop pixelbot` 또는 화면에서 "전체 청산 + 오토 OFF"

## 알아둘 한계 (중요)
- **이 코드는 가짜 Bybit/TradingAgents 모듈로만 테스트했어요.** 진짜 Bybit·TradingAgents 와는 실행 검증을 못 했어요. 반드시 paper → testnet 을 거치세요.
- Bybit 현물 시장가 매수/체결 정보 처리(ccxt 버전별 차이)는 실제 환경에서 어긋날 수 있어요. testnet 에서 주문 기록이 맞는지 꼭 확인하세요.
- 현물 롱 온리예요(공매도·레버리지 없음). 손절은 20초 주기의 소프트웨어 감시라서, 서버가 꺼져 있으면 작동하지 않아요. 큰 금액이라면 거래소 쪽 조건부 주문을 추가하세요.
- LLM 호출이 많아요. 종목 수 × 분석 주기 × 토론 라운드에 비례해서 비용이 늘어요.
- 어떤 AI 판정도 수익을 보장하지 않아요. 손실은 전부 본인 책임이에요.
