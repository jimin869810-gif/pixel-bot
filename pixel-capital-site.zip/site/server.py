"""
개인용 웹 서버 (표준 라이브러리만 사용). 로그인은 HTTP Basic 인증이에요.

실행:  set -a; source .env; set +a; python server.py
기본은 127.0.0.1:8080 에만 열려요. 밖에서 쓰려면 Tailscale(권장) 이나 HTTPS 리버스 프록시를 쓰세요.
"""
import hmac
import json
import logging
import os
import time
from base64 import b64decode
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from engine import Config, Engine

STATIC = Path(__file__).parent / "static"
USER = os.getenv("DASH_USER", "admin")
PASSWORD = os.getenv("DASH_PASSWORD", "")
FAILS = {}  # ip -> [시각들]  (무차별 대입 방지)

HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'",
}


def make_handler(engine):
    class H(BaseHTTPRequestHandler):
        server_version = "PixelCapital"

        def log_message(self, fmt, *args):
            logging.getLogger("http").debug(fmt, *args)

        # ---- 공통 ----
        def _send(self, code, body, ctype="application/json; charset=utf-8", extra=None):
            data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            for k, v in {**HEADERS, **(extra or {})}.items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def _auth(self):
            ip = self.client_address[0]
            now = time.time()
            recent = [t for t in FAILS.get(ip, []) if now - t < 600]
            FAILS[ip] = recent
            if len(recent) >= 10:
                self._send(429, {"error": "too many attempts"})
                return False
            ok = False
            h = self.headers.get("Authorization", "")
            if h.startswith("Basic "):
                try:
                    u, _, p = b64decode(h[6:]).decode().partition(":")
                    ok = hmac.compare_digest(u.encode(), USER.encode()) & hmac.compare_digest(p.encode(), PASSWORD.encode())
                except Exception:
                    ok = False
            if not ok:
                if h:
                    FAILS[ip].append(now)
                    time.sleep(1)
                self._send(401, {"error": "auth required"}, extra={"WWW-Authenticate": 'Basic realm="Pixel Capital"'})
            return ok

        # ---- GET ----
        def do_GET(self):
            if not self._auth():
                return
            u = urlparse(self.path)
            q = parse_qs(u.query)
            try:
                if u.path in ("/", "/index.html"):
                    self._send(200, (STATIC / "index.html").read_bytes(), "text/html; charset=utf-8")
                elif u.path == "/api/state":
                    self._send(200, engine.snapshot())
                elif u.path == "/api/candles":
                    self._send(200, engine.candles((q.get("coin") or ["BTC"])[0].upper()))
                elif u.path == "/api/decisions":
                    coin = (q.get("coin") or [""])[0].upper()
                    rows = [d for d in engine.decisions if not coin or d["coin"] == coin][-20:][::-1]
                    self._send(200, rows)
                else:
                    self._send(404, {"error": "not found"})
            except Exception as e:
                logging.getLogger("http").exception("GET 실패")
                self._send(500, {"error": str(e)[:200]})

        # ---- POST ----
        def do_POST(self):
            if not self._auth():
                return
            if self.headers.get("X-Requested-With") != "pixel":  # 다른 사이트에서 몰래 보내는 요청 차단
                return self._send(403, {"error": "forbidden"})
            try:
                n = min(int(self.headers.get("Content-Length") or 0), 10_000)
                body = json.loads(self.rfile.read(n) or b"{}")
                p = urlparse(self.path).path
                if p == "/api/auto":
                    engine.set_auto(bool(body.get("on")))
                    self._send(200, {"ok": True})
                elif p == "/api/run":
                    engine.run_now()
                    self._send(200, {"ok": True})
                elif p == "/api/close":
                    self._send(200, {"result": engine.close(str(body.get("coin", "")).upper())})
                elif p == "/api/close_all":
                    if body.get("confirm") is not True:
                        return self._send(400, {"error": "confirm required"})
                    self._send(200, {"result": engine.close_all()})
                else:
                    self._send(404, {"error": "not found"})
            except Exception as e:
                logging.getLogger("http").exception("POST 실패")
                self._send(500, {"error": str(e)[:200]})

    return H


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    if len(PASSWORD) < 8:
        raise SystemExit("DASH_PASSWORD (8자 이상)를 .env 에 설정하세요. 비밀번호 없이는 시작하지 않아요.")
    cfg = Config()
    engine = Engine(cfg)
    engine.start()
    host, port = os.getenv("BIND", "127.0.0.1"), int(os.getenv("PORT", "8080"))
    srv = ThreadingHTTPServer((host, port), make_handler(engine))
    logging.info("웹 서버 시작 http://%s:%s (모드: %s)", host, port, cfg.mode)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        engine.shutdown()


if __name__ == "__main__":
    main()
