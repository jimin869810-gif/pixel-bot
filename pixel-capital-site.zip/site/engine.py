"""
매매 엔진: TradingAgents(멀티에이전트 LLM) 판정 -> Bybit(ccxt) 주문.

모드(MODE 환경변수)
  paper   : 주문을 내지 않는 모의투자. 시세만 Bybit 에서 가져와요. (기본)
  testnet : Bybit 테스트넷 계정으로 실제 주문 흐름을 검증해요. (가짜 돈)
  live    : Bybit 실계좌. CONFIRM_LIVE=I_UNDERSTAND_THE_RISK 가 있어야 켜져요.

현물(spot) 롱 온리: BUY 판정이면 매수, SELL 판정이면 보유분 청산, HOLD 는 유지.
안전장치: 1회 주문 상한, 일일 손실 한도, 손절/익절 감시(60초 미만 주기), 긴급 정지.
"""
import datetime as dt
import json
import logging
import os
import threading
import time
from collections import deque
from pathlib import Path

log = logging.getLogger("engine")


def parse_decision(raw):
    """판정 문자열에서 가장 먼저 나오는 BUY/SELL/HOLD 를 고릅니다."""
    text = str(raw).upper()
    alias = {"BUY": "BUY", "OVERWEIGHT": "BUY", "SELL": "SELL", "UNDERWEIGHT": "SELL", "HOLD": "HOLD"}
    hits = [(text.find(k), v) for k, v in alias.items() if k in text]
    return min(hits)[1] if hits else "HOLD"


def collect_reports(state):
    """캐릭터별로 보여줄 분석가 리포트. 키 이름이 버전마다 다르면 비어 있을 수 있어요."""
    s = state if isinstance(state, dict) else {}
    deb = s.get("investment_debate_state") or {}
    risk = s.get("risk_debate_state") or {}
    pick = {
        "TARO": s.get("market_report"),
        "DIANA": s.get("fundamentals_report"),
        "NOVA": s.get("news_report"),
        "VIBE": s.get("sentiment_report"),
        "BULL": deb.get("bull_history"),
        "BEAR": deb.get("bear_history"),
        "GUARD": risk.get("judge_decision") or risk.get("history"),
        "ACE": s.get("final_trade_decision"),
    }
    return {k: str(v)[:1500] for k, v in pick.items() if v}


class Config:
    def __init__(self):
        e = os.getenv
        self.mode = e("MODE", "paper").lower()
        if self.mode not in ("paper", "testnet", "live"):
            raise SystemExit("MODE 는 paper / testnet / live 중 하나여야 해요")
        if self.mode == "live" and e("CONFIRM_LIVE") != "I_UNDERSTAND_THE_RISK":
            raise SystemExit("실거래(live)는 CONFIRM_LIVE=I_UNDERSTAND_THE_RISK 를 설정해야 켜져요")
        # TradingAgents 티커 -> Bybit 현물 심볼
        self.symbols = dict(
            p.strip().split(":")
            for p in e("SYMBOLS", "BTC-USD:BTC/USDT,ETH-USD:ETH/USDT,SOL-USD:SOL/USDT").split(",")
        )
        self.interval_h = float(e("INTERVAL_HOURS", "4"))
        self.alloc = float(e("ALLOC_PCT", "0.10"))
        self.max_order = float(e("MAX_ORDER_USDT", "100"))
        self.daily_loss = float(e("DAILY_LOSS_LIMIT", "0.05"))
        self.stop_loss = float(e("STOP_LOSS_PCT", "0.05"))
        self.take_profit = float(e("TAKE_PROFIT_PCT", "0.10"))
        self.paper_start = float(e("PAPER_START_USDT", "10000"))
        self.fee = float(e("FEE", "0.001"))
        self.debate_rounds = int(e("DEBATE_ROUNDS", "1"))
        self.save_reports = e("SAVE_REPORTS", "0") == "1"
        self.data_dir = Path(e("DATA_DIR", "data"))
        self.tick_sec = int(e("TICK_SECONDS", "20"))


def default_exchange(cfg):
    import ccxt

    params = {"enableRateLimit": True, "options": {"defaultType": "spot"}}
    if cfg.mode in ("testnet", "live"):
        params["apiKey"] = os.environ["BYBIT_API_KEY"]
        params["secret"] = os.environ["BYBIT_API_SECRET"]
    ex = ccxt.bybit(params)
    if cfg.mode == "testnet":
        ex.set_sandbox_mode(True)
    ex.load_markets()
    return ex


def default_agents(cfg):
    from tradingagents.default_config import DEFAULT_CONFIG
    from tradingagents.graph.trading_graph import TradingAgentsGraph

    c = DEFAULT_CONFIG.copy()
    c["llm_provider"] = os.getenv("LLM_PROVIDER", "anthropic")
    c["deep_think_llm"] = os.getenv("DEEP_MODEL", "claude-sonnet-5-5")
    c["quick_think_llm"] = os.getenv("QUICK_MODEL", "claude-haiku-5-5")
    c["max_debate_rounds"] = cfg.debate_rounds
    return TradingAgentsGraph(debug=False, config=c)


class Engine:
    def __init__(self, cfg, exchange_factory=default_exchange, agents_factory=default_agents):
        self.cfg = cfg
        self._exf, self._taf = exchange_factory, agents_factory
        self.lock = threading.RLock()   # 상태
        self.xlock = threading.RLock()  # 거래소 호출 (순서: lock -> xlock)
        self.wake = threading.Event()
        self.halt = threading.Event()
        self.ex = None
        self.ta = None
        self.prices = {}
        self.usdt_total = self.usdt_free = None
        self.price_ts = 0.0
        self.error = None
        self.status = {"phase": "starting", "ticker": None, "since": time.time()}
        self.force = False
        self.candle_cache = {}
        cfg.data_dir.mkdir(parents=True, exist_ok=True)
        self.state_file = cfg.data_dir / "state.json"
        self.log_file = cfg.data_dir / "decisions.jsonl"
        self.state = self._load()
        self.decisions = deque(maxlen=300)
        self._load_decisions()
        self.next_run = time.time() + 5
        self.thread = None

    # ---------- 저장/불러오기 ----------
    def _load(self):
        if self.state_file.exists():
            try:
                return json.loads(self.state_file.read_text())
            except Exception:
                log.exception("state.json 을 읽지 못해 새로 시작합니다")
        return {"cash": self.cfg.paper_start, "pos": {}, "trades": [],
                "auto": self.cfg.mode != "live",  # 실거래는 직접 켜기 전엔 꺼진 상태로 시작
                "day": "", "day_start_equity": None, "start_equity": None}

    def _save(self):
        tmp = self.state_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.state, indent=2, ensure_ascii=False))
        tmp.replace(self.state_file)

    def _load_decisions(self):
        if not self.log_file.exists():
            return
        for line in self.log_file.read_text().splitlines()[-300:]:
            try:
                self.decisions.append(json.loads(line))
            except Exception:
                pass

    # ---------- 수명주기 ----------
    def start(self):
        self.thread = threading.Thread(target=self._loop, name="engine", daemon=True)
        self.thread.start()

    def shutdown(self):
        self.halt.set()
        self.wake.set()

    def _loop(self):
        log.info("엔진 시작 | 모드=%s | 종목=%s | 주기=%sh", self.cfg.mode, list(self.cfg.symbols), self.cfg.interval_h)
        while not self.halt.is_set():
            try:
                if self.ex is None:
                    self.ex = self._exf(self.cfg)
                self._tick()
                if self.error and not self.error.get("transient"):
                    self.error = None  # 연결 오류는 시세 조회가 다시 성공하면 사라져요
                if self.status["phase"] in ("starting", "error"):
                    self._set_status("idle")
                if self.force or (self.state["auto"] and time.time() >= self.next_run):
                    self._cycle()
            except Exception as e:
                log.exception("엔진 오류")
                self.error = {"t": dt.datetime.now().isoformat(timespec="seconds"), "ts": time.time(),
                              "msg": f"{type(e).__name__}: {e}"[:300]}
                self._set_status("error")
            self.wake.wait(self.cfg.tick_sec)
            self.wake.clear()

    def _set_status(self, phase, ticker=None):
        self.status = {"phase": phase, "ticker": ticker, "since": time.time()}

    # ---------- 시세와 감시 ----------
    def _tick(self):
        with self.xlock:
            tick = self.ex.fetch_tickers(list(self.cfg.symbols.values()))
            bal = self.ex.fetch_balance() if self.cfg.mode != "paper" else None
        with self.lock:
            for sym, t in tick.items():
                if t.get("last"):
                    self.prices[sym] = float(t["last"])
            if bal:
                self.usdt_total = float(bal["total"].get("USDT") or 0)
                self.usdt_free = float(bal["free"].get("USDT") or 0)
            self.price_ts = time.time()
            eq = self._equity()
            if self.state["start_equity"] is None:
                self.state["start_equity"] = eq
            today = dt.date.today().isoformat()
            if self.state["day"] != today:
                self.state["day"], self.state["day_start_equity"] = today, eq
            self._check_stops()
            self._save()

    def _check_stops(self):
        for sym in list(self.state["pos"]):
            p, px = self.state["pos"][sym], self.prices.get(sym)
            if not px:
                continue
            pct = px / p["entry"] - 1
            try:
                if pct <= -self.cfg.stop_loss:
                    self._sell(sym, px, "GUARD 손절")
                elif pct >= self.cfg.take_profit:
                    self._sell(sym, px, "목표가 익절")
            except Exception as e:
                log.exception("손절/익절 실패 %s", sym)
                self.error = {"t": dt.datetime.now().isoformat(timespec="seconds"), "ts": time.time(),
                              "msg": f"{sym} 청산 실패: {e}"[:300], "transient": True}

    # ---------- 계좌 ----------
    def _free(self):
        return self.state["cash"] if self.cfg.mode == "paper" else (self.usdt_free or 0.0)

    def _equity(self):
        pos_val = sum(p["qty"] * self.prices.get(s, p["entry"]) for s, p in self.state["pos"].items())
        base = self.state["cash"] if self.cfg.mode == "paper" else (self.usdt_total or 0.0)
        return base + pos_val

    def _halted(self):
        d = self.state["day_start_equity"]
        return bool(d) and self._equity() < d * (1 - self.cfg.daily_loss)

    def _min_cost(self, sym):
        m = (self.ex.markets or {}).get(sym) or {}
        return float(((m.get("limits") or {}).get("cost") or {}).get("min") or 0)

    # ---------- 주문 ----------
    def _confirm(self, order, sym):
        """Bybit 는 주문 직후 체결 정보가 비어 올 수 있어서 한 번 더 조회해요."""
        for _ in range(3):
            if order.get("filled"):
                return order
            time.sleep(0.6)
            try:
                order = self.ex.fetch_order(order["id"], sym)
            except Exception:
                pass
        return order

    def _buy(self, ticker, sym, price):
        cfg, s = self.cfg, self.state
        notional = min(self._equity() * cfg.alloc, cfg.max_order, self._free() * 0.98)
        if notional < max(10.0, self._min_cost(sym) if self.ex else 0):
            return "자금 부족으로 매수 못함"
        if cfg.mode == "paper":
            qty, entry = notional / price, price
            s["cash"] -= notional * (1 + cfg.fee)
        else:
            with self.xlock:
                cost = round(notional, 2)
                if self.ex.has.get("createMarketBuyOrderWithCost"):
                    o = self.ex.create_market_buy_order_with_cost(sym, cost)
                else:
                    o = self.ex.create_order(sym, "market", "buy", cost, None, {"marketUnit": "quoteCoin"})
                o = self._confirm(o, sym)
            filled = float(o.get("filled") or cost / price)
            entry = float(o.get("average") or price)
            qty = filled * (1 - cfg.fee)  # 현물 매수 수수료는 받은 코인에서 빠져요 (근사치)
            self.usdt_free = max(0.0, (self.usdt_free or 0) - cost)
        s["pos"][sym] = {"ticker": ticker, "qty": qty, "entry": entry, "t": time.time()}
        self._save()
        return f"매수 {qty:.6f} @ {entry:,.2f}"

    def _sell(self, sym, price, why):
        cfg, s = self.cfg, self.state
        p = s["pos"][sym]
        qty, exit_px = p["qty"], price
        if cfg.mode == "paper":
            s["cash"] += qty * price * (1 - cfg.fee)
        else:
            with self.xlock:
                base = sym.split("/")[0]
                free = float(self.ex.fetch_balance()["free"].get(base) or 0)
                amount = float(self.ex.amount_to_precision(sym, min(qty, free)))
                m = (self.ex.markets or {}).get(sym) or {}
                mn = float(((m.get("limits") or {}).get("amount") or {}).get("min") or 0)
                if amount <= 0 or amount < mn:
                    del s["pos"][sym]
                    self._save()
                    return "수량이 너무 작아 포지션 기록만 정리"
                o = self._confirm(self.ex.create_market_sell_order(sym, amount), sym)
            exit_px = float(o.get("average") or price)
            qty = float(o.get("filled") or amount)
        pnl = (exit_px - p["entry"]) * qty - (p["entry"] + exit_px) * qty * cfg.fee
        s["trades"].insert(0, {"t": dt.datetime.now().isoformat(timespec="seconds"), "sym": sym.split("/")[0],
                               "qty": qty, "entry": p["entry"], "exit": exit_px, "pnl": pnl, "why": why})
        del s["trades"][200:]
        del s["pos"][sym]
        self._save()
        return f"청산 {qty:.6f} @ {exit_px:,.2f} ({why})"

    # ---------- 분석 사이클 ----------
    def _portfolio(self):
        try:
            from tradingagents.portfolio import PortfolioContext
        except ImportError:
            return {}
        s = self.state
        return {"portfolio": PortfolioContext.model_validate({
            "cash": round(self._free(), 2), "currency": "USD",
            "positions": [{"ticker": p["ticker"], "quantity": p["qty"], "average_price": p["entry"]}
                          for p in s["pos"].values()]})}

    def _cycle(self):
        self.force = False
        if self.ta is None:
            self.ta = self._taf(self.cfg)
        today = dt.date.today().isoformat()
        for ticker, sym in self.cfg.symbols.items():
            if self.halt.is_set():
                return
            self._set_status("analyzing", ticker)
            try:
                with self.lock:
                    extra = self._portfolio()
                final_state, raw = self.ta.propagate(ticker, today, **extra)  # 수 분 걸리는 호출 (락 없이)
                if self.cfg.save_reports:
                    self.ta.save_reports(final_state, ticker)
                decision = parse_decision(raw)
                with self.lock:
                    action = self._act(ticker, sym, decision)
                    rec = {"t": dt.datetime.now().isoformat(timespec="seconds"), "ticker": ticker,
                           "coin": ticker.split("-")[0], "decision": decision, "action": action,
                           "price": self.prices.get(sym), "equity": self._equity(), "mode": self.cfg.mode,
                           "reports": collect_reports(final_state)}
                    self.decisions.append(rec)
                    with self.log_file.open("a") as f:
                        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                log.info("%s %s -> %s", ticker, decision, action)
            except Exception as e:
                log.exception("%s 분석 실패", ticker)
                self.error = {"t": dt.datetime.now().isoformat(timespec="seconds"), "ts": time.time(),
                              "msg": f"{ticker}: {type(e).__name__}: {e}"[:300], "transient": True}
        self.next_run = time.time() + self.cfg.interval_h * 3600
        self._set_status("idle")

    def _act(self, ticker, sym, decision):
        if not self.state["auto"]:
            return "분석만 (오토 OFF)"
        price = self.prices.get(sym)
        if not price:
            return "시세 없음"
        if decision == "BUY" and sym not in self.state["pos"]:
            if self._halted():
                return "일일 손실 한도 도달: 매수 보류"
            return self._buy(ticker, sym, price)
        if decision == "SELL" and sym in self.state["pos"]:
            return self._sell(sym, price, "ACE SELL 판정")
        return "-"

    # ---------- 웹 API 용 ----------
    def snapshot(self):
        with self.lock:
            s, cfg = self.state, self.cfg
            eq = self._equity()
            start = s["start_equity"] or eq
            pos = []
            for sym, p in s["pos"].items():
                px = self.prices.get(sym, p["entry"])
                pos.append({"coin": sym.split("/")[0], "qty": p["qty"], "entry": p["entry"], "price": px,
                            "pnl": (px - p["entry"]) * p["qty"], "pct": (px / p["entry"] - 1) * 100})
            last = {}
            for d in self.decisions:
                last[d["coin"]] = {k: d[k] for k in ("t", "decision", "action", "price", "reports", "mode")}
            return {
                "mode": cfg.mode, "auto": s["auto"], "status": dict(self.status),
                "next_run": self.next_run if s["auto"] else None, "interval_h": cfg.interval_h,
                "coins": [t.split("-")[0] for t in cfg.symbols],
                "prices": {sym.split("/")[0]: px for sym, px in self.prices.items()},
                "price_age": time.time() - self.price_ts if self.price_ts else None,
                "equity": eq, "start_equity": start, "pnl": eq - start, "pnl_pct": (eq / start - 1) * 100 if start else 0,
                "halted": self._halted(), "positions": pos, "trades": s["trades"][:30],
                "decisions": last, "history": [{k: d[k] for k in ("t", "coin", "decision", "action")} for d in list(self.decisions)[-20:]][::-1],
                "limits": {"max_order": cfg.max_order, "alloc": cfg.alloc, "stop_loss": cfg.stop_loss,
                           "take_profit": cfg.take_profit, "daily_loss": cfg.daily_loss},
                "error": self.error if self.error and time.time() - self.error.get("ts", 0) < 3600 else None,
                "now": time.time(),
            }

    def candles(self, coin, tf="15m", limit=96):
        sym = next((v for k, v in self.cfg.symbols.items() if k.split("-")[0] == coin), None)
        if not sym or self.ex is None:
            return []
        key = (sym, tf)
        hit = self.candle_cache.get(key)
        if hit and time.time() - hit[0] < 30:
            return hit[1]
        with self.xlock:
            data = self.ex.fetch_ohlcv(sym, tf, limit=limit)
        self.candle_cache[key] = (time.time(), data)
        return data

    def set_auto(self, on):
        with self.lock:
            self.state["auto"] = bool(on)
            if on:
                self.next_run = min(self.next_run, time.time() + 5)
            self._save()
        self.wake.set()

    def run_now(self):
        self.force = True
        self.wake.set()

    def close(self, coin):
        with self.lock:
            sym = next((v for v in self.cfg.symbols.values() if v.split("/")[0] == coin), None)
            if not sym or sym not in self.state["pos"]:
                return "해당 포지션이 없어요"
            return self._sell(sym, self.prices.get(sym) or self.state["pos"][sym]["entry"], "수동 청산")

    def close_all(self):
        with self.lock:
            self.state["auto"] = False  # 청산 후 바로 재매수하지 않도록 오토 OFF
            out = []
            for sym in list(self.state["pos"]):
                try:
                    out.append(self._sell(sym, self.prices.get(sym) or self.state["pos"][sym]["entry"], "전체 청산"))
                except Exception as e:
                    out.append(f"{sym} 실패: {e}")
            self._save()
            return out or ["청산할 포지션이 없어요"]
